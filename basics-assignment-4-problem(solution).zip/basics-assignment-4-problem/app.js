const app = Vue.createApp({
    data() {
        return {
            enteredClass: null,
            showParagraph: true,
            setColor: null,
            inlineStyle: null
        }
    },
    computed: {
        styleMe(){
            if(this.enteredClass == 'user1'){
                return 'user1'
            }else if(this.enteredClass == 'user2'){
                return 'user2'
            }else{
                return 'Style me!'
            }
        },
        showHide(){
            if(this.showParagraph == true){
                return 'visible'
            }else{
                return 'hidden'
            }
        }
    },
    methods: {
        toggleParagraph() {
            this.showParagraph = !this.showParagraph;
            console.log(this.showParagraph)
        },
        setBackground(){
            console.log('pressed')
            this.setColor = this.inlineStyle
        }
    }
});

app.mount('#assignment');