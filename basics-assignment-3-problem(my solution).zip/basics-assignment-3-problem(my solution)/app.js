const app = Vue.createApp({
    data() {
        return {
            counter: 0
        }
    },
    computed: {
        result() {
            if(this.counter < 37){
                return "Not there yet"
            }else if(this.counter === 37){
                return 37
            }else{
                return "Too much!"
            }
        }
    },
    watch: {
        counter(){
            var that = this
            setTimeout(function(){
                that.counter = 0
            }, 5000)
        }
    },
    methods: {
        increment(val) {
            this.counter = this.counter + val
            console.log(this.counter)
        }
    }
});

app.mount('#assignment');