const app = Vue.createApp({
    data() {
        return {
            tasks: [],
            inputTaskValue: null,
            hideListValue: true
        }
    },
    computed: {
        showText(){
            if(this.hideListValue == true){
                return 'Hide'
            }else{
                return 'Show'
            }
        }
    },
    methods: {
        addTask() {
            this.tasks.push(this.inputTaskValue)
            this.inputTaskValue = null
        },
        hideList() {
            this.hideListValue = !this.hideListValue
        }
    }
});

app.mount('#assignment');