const app = Vue.createApp({
    data() {
        return {
            register: '',
            enteredText: ''
        }
    },
    methods: {
        showAlert() {
            alert('Some text')
        },
        registerText(event){
            this.register = event.target.value
        },
        enterKey(event) {
            this.enteredText = event.target.value
        }
    }
});

app.mount('#assignment');