<template>
    <div>
        <active-user :getUsername="username" :getAge="age"/>
        <user-data @updateActiveUser="updateActiveUser"/>
    </div>
</template>
<script>
export default {
    data(){
        return {
            username: null,
            age: null
        }
    },
    methods: {
        updateActiveUser(info){
            this.username = info.username
            this.age = info.age
        }
    }
}
</script>