<template>
    <div>
        <input type="text" v-model="username" @keyup="submit" placeholder="Enter Username">
        <input type="text" v-model="age" @keyup="submit" placeholder="Enter Age">
        <button type="submit">Submit</button>
    </div>
</template>
<script>
export default {
    data(){
        return {
            username: null,
            age: null
        }
    },
    methods: {
        submit(){
            this.$emit('updateActiveUser', {
                username: this.username,
                age: this.age
            })
        }
    }
}
</script>