<template>
    <div>
        <h2>Username: {{ getUsername }}</h2>
        <h3>Age: {{ getAge }}</h3>
    </div>
</template>
<script>
export default {
    props: ['getUsername', 'getAge']
}
</script>